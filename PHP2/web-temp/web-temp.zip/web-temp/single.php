<?php include('header.php'); ?>
			<div id="content">
				<div id="main">
					<h2><?php echo $the_title; ?></h2>
					<?php echo $the_content; ?>
				</div>
				<?php include('sidebar.php'); ?>
			</div>
<?php include('footer.php'); ?>