<?php
	$the_title = 'About';
	$the_content = '<p>This is the about page. Here\'s where you would explain all about your site or company and let visitors get to know you and your staff.</p>';
?>

<?php include('single.php'); ?>