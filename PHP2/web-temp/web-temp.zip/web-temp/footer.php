			<div id="footer">
				<div class="footer_half">
					<p>&copy;John Morris 2012</p>
				</div>
				<div class="footer_half t_align_right">
					<p>Powered by <a href="http://learnphp.co">Learn PHP</a></p>
				</div>
			</div>
		</div>
	</body>
</html>