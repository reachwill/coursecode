			<div id="sidebar">
				<h3>Sidebar Header</h3>
				<p>This is your sidebar area</p>
			</div>