<?php
	$the_title = 'Home';
	$the_content = '<p>This is the home page.</p>';
?>

<?php include('single.php'); ?>